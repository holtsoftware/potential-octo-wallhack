/*
 * BugBug.java
 *
 * Created on June 16, 2002, 8:01 PM
 */

/**
 *
 * @author  adam
 * @version 
 */
public class BugBug extends BugTile {

    /** Creates new BugBug */
    public BugBug() {
    }

}

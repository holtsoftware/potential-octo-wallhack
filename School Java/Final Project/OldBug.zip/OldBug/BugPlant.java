/*
 * BugPlant.java
 *
 * Created on June 16, 2002, 8:01 PM
 */

/**
 *
 * @author  adam
 * @version 
 */
public class BugPlant extends BugTile {

    /** Creates new BugPlant */
    public BugPlant() {
    }
    
    /** */
    public AIAction getAIAction(Vector
}

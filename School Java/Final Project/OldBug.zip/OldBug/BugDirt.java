/*
 * BugDirt.java
 *
 * Created on June 16, 2002, 7:56 PM
 *
 * This class das the exact same thing as ButTile so noting realy needs to be done
 */

/**
 *
 * @author  adam
 * @version 
 */
public class BugDirt extends BugTile {

    /** Creates new BugDirt */
    public BugDirt() {
        super();
        setType(Dirt);
    }
}

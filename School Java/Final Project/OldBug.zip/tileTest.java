/*
 * tileTest.java
 *
 * Created on July 20, 2002, 11:41 AM
 */

/**
 *
 * @author  adam
 */
public class tileTest {
    
    /** Creates a new instance of tileTest */
    public tileTest() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
		AIEnvironment env = new AIEnvironment();
		Water wt = new Water();
    }
    
}

// vim:ts=4

import javax.swing.*;

public class MudClient{
    public static void main(String[] args){
        JFrame frame = new MudFrame();
        frame.addWindowListener(new WindowCloser());
        frame.setVisible(true);
        try{
            MudSocket ms = new MudSocket("localhost",3011,(MudFrame)frame);
            ms.connect();
            ms.SendText("connected\n\r");
            System.out.println("after Connected");
        }
        catch(Exception e){
            System.err.println("Exception: " + e.getMessage());
        }
    }
}

import java.net.*;
import java.io.*;
import javax.swing.*;

public class MudSocket {
    public MudSocket(String hostname, int port, MudFrame topost) throws Exception {
        try{
            socket = new Socket(hostname,port);
        }
        catch(UnknownHostException e){
            throw new Exception("Unknown host: " + e.getMessage());
        }
        catch(IOException e){
            throw new Exception("IOException on socket creation: " + e.getMessage());
        }
        mcFrame = topost;
    }

    public void connect() {
        Socket mud = getSocket();
        try{
            InputStream inStream = mud.getInputStream();
            BufferedReader reader = new BufferedReader(
                        new InputStreamReader(inStream));
            String date;
            while(true)
            {
                date = reader.readLine();
                reader.skip(2);
                mcFrame.addText(date + "\n");
                System.out.print(date+ "\n");
            }
        }
        catch(IOException e){
            System.err.println(e.getMessage());
        }
    }

    public void SendText(String Text)
    {
        Socket mud = getSocket();
        try{
            OutputStream oStream = mud.getOutputStream();
            BufferedWriter writer = new BufferedWriter(
                         new OutputStreamWriter(oStream));
          
            writer.write(Text);
            writer.flush();
        }
        catch(IOException e){
            System.err.println(e.getMessage());
        }
    }

    protected Socket getSocket(){
        return socket;
    }
    
    private Socket socket;
    private MudFrame mcFrame;
}

import java.net.*;
import java.io.*;

        // Contact the daytime server running on hostname.
class DaytimeClient {
        // Contact the server at the appropriate port and set
        // the socket attribute for the run() method to use.
    public DaytimeClient(String hostname) throws Exception {
        // The well-known port of the TCP daytime service.
        final int DaytimePort = 13;
        try{
            socket = new Socket(hostname,DaytimePort);
        }
        catch(UnknownHostException e){
            throw new Exception("Unknown host: "+e.getMessage());
        }
        catch(IOException e){
            throw new Exception("IOException on socket creation: "+e.getMessage());
        }
    }

        // Obtain the time of day from the daytime server.
    public void run() {
        Socket daytime = getSocket();
        try{
            // Get the stream used by the server to send data.
            InputStream inStream = daytime.getInputStream();
            // Wrap the stream in a BufferedReader.
            BufferedReader reader = new BufferedReader(
                        new InputStreamReader(inStream));

            // The server will only send a single line.
            String response = reader.readLine();
            System.out.println(response);
            // Close the connection now it is finished with.
            daytime.close();
        }
        catch(IOException e){
            System.err.println(e.getMessage());
        }
    }

    protected Socket getSocket(){
        return socket;
    }

    private final Socket socket;
}

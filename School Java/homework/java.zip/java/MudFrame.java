import javax.swing.*;
import java.awt.*;

public class MudFrame extends JFrame{
    public MudFrame(){
        super("NEE's Mud Client");
        setSize(300,200);
        
        Container con = getContentPane();
        Container ocon = new Container();
        text.setAutoscrolls(true);
       
        con.add(text,"Center");
        ocon.setLayout(new BorderLayout());
        ocon.add(uText,"Center");
        text.setEditable(false);
        text.setFont(new Font("terminal",Font.PLAIN,12));
        
        JButton Benter = new JButton("Send");

        ocon.add(Benter,"East"); 
        con.add(ocon,"South"); 
    }

    public void addText(String str){
        text.setText(text.getText() + str);
    }

    public String getText(){
        return text.getText();
    }

    protected final JTextPane text = new JTextPane();
    protected final JTextField uText = new JTextField();
}

        // Illustrate connection to a daytime server running on
        // the host named in the command line argument.
public class DaytimeMain {
    public static void main(String[] args) {
        if(args.length == 1){
            try{
                DaytimeClient client = new DaytimeClient(args[0]);
                client.run();
            }
            catch(Exception e){
                System.err.println("Exception: "+e.getMessage());
            }
        }
        else{
            System.err.println("You must supply the name of a host to contact.");
        }
    }
}

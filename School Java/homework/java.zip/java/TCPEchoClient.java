// Adam Holt
// lab2
// week 10

import java.net.*;
import java.io.*;


        // Contact the echo server running on hostname.
class TCPEchoClient {
        // Contact the server at the appropriate port and set
        // the socket attribute for the run() method to use.
    public TCPEchoClient(String hostname) throws Exception {
        try{
            // The well-known port of the TCP echo service.
            final int EchoPort = 24101;
            socket = new Socket(hostname,EchoPort);
        }
        catch(UnknownHostException e){
            throw new Exception("Unknown host: "+e.getMessage());
        }
        catch(IOException e){
            throw new Exception("IOException on socket creation: "+e.getMessage());
        }
    }

        // Send the sample strings to the echo server and read
        // back the responses.
    public void run() {
        Socket echo = getSocket();

        try{
	        String toSendString = doMyStuff();
            // Wrap the input stream in a BufferedReader.
            BufferedReader reader = new BufferedReader(
                        new InputStreamReader(echo.getInputStream()));
            // Wrap the output stream in a BufferedWriter.
            BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(echo.getOutputStream()));

            // Send each string and read the response.
			while(!toSendString.equals("."))
			{
                System.out.println("Sending: "+toSendString);

                writer.write(toSendString);
                writer.newLine();
                // Make sure the data is flushed to the stream.
                writer.flush();

                // Read the response.
                String response = reader.readLine();
                System.out.println("The response is: "+response);
	        	toSendString = doMyStuff();
			}
            // Close the connection now it is finished with.
            echo.close();
        }
        catch(IOException e){
            System.err.println(e.getMessage());
        }
    }

	public String doMyStuff()
	{
	    System.out.println("Enter the text you wont me to have the server echo back.");

		BufferedReader myReader = new BufferedReader(
						new InputStreamReader(System.in));

		String tosend="";
		try{
				tosend = myReader.readLine();
		}
		catch(IOException e){
				System.err.println(e.getMessage());
		}
		return tosend;
	}

    protected Socket getSocket(){
        return socket;
    }

    private final Socket socket;
}

/*
Enter the text you wont me to have the server echo back.
hi there im here
Sending: hi there im here

The response is: hi there im here
*/
